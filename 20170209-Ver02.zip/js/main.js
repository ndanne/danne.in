$(document).ready(function() {
	/* LHS Toggle */
	$('body').on('click', function(e) {
	  	if($(e.target).closest('#navbar').length == 0) {
	      $('#navbar').removeClass('active');
			$('#nav-toggle').removeClass('active');
			$('#overlay').css('visibility','hidden');
	    }
	    if($(e.target).closest('#nav_refine').length == 0 || $(e.target).parent().hasClass('refine-by-close')) {
	      $('#nav_refine').removeClass('active');
			$('#refine_xs').removeClass('active');
			$('#overlay').css('visibility','hidden');
	    }
	});

	$('#nav-toggle').click(function(e){
		if ($('#navbar').hasClass("active")) {
			  $('#navbar').removeClass('active');
			  $(this).removeClass('active');
			  	$('#overlay').css('visibility','hidden');	  
		} else {
			 $('#navbar').addClass('active');
			 $(this).addClass('active'); 
			 $('#overlay').css('visibility','visible');
		}
		e.stopPropagation(); 
	});
	
	//Back Top Link
	 $(window).scroll(function() {
	    if ($(this).scrollTop() > 400) {
	      $('.back-to-top').fadeIn(400);
	    } else {
	      $('.back-to-top').fadeOut(400);
	    }
	 });

	 $('.back-to-top').click(function(e) {
	    e.preventDefault();
	    $('html, body').animate({scrollTop:0}, 500);
	    return false;
	 });

});

// Ends - document.ready

$(window).load(function () {
	//headPosition();
	$('#refine_xs').on('click', function(e){
		if ($('#nav_refine').hasClass("active")) {
			  $('#nav_refine').removeClass('active');
			  $(this).removeClass('active');
			  	$('#overlay').css('visibility','hidden');	  
		} else {
			 $('#nav_refine').addClass('active');
			 $(this).addClass('active'); 
			 $('#overlay').css('visibility','visible');
		}
		e.stopPropagation(); 
	});
});

// $(window).resize(function () {
// 	headPosition();
// });

// Header height
function headPosition(){
	//$('#hidden-header').css({ 'height' : $('header').height()});
	$('body').css({ 'margin-bottom' : $('footer').height()});
}

function fnLoading(status){
	  if(status) {
		  $('#overlay, #overlay-bg').css('visibility','visible');
		} else {
		  $('#overlay, #overlay-bg').css('visibility','hidden');
		}
}

/*----------------------------------------------------*/
/*	Ajax page Load Method 
/*----------------------------------------------------*/
function fnLoadPage(page) {
	  if (page != null) {
		fnLoading(true);
		$("#page_content").load(page, function () {
			fnLoading(false);
			$('html, body').animate({scrollTop:0},500);
			$('[data-toggle="tooltip"]').tooltip();
		});
	}
}

/*----------------------------------------------------*/
/*	Loading Time
/*----------------------------------------------------*/
function loadContent(){
  	// fnLoadPage("htmls/home.html");
  	// fnLoadPage("htmls/board-calendar.html");
  	fnLoadPage("htmls/eds-search.html");
}

//  HEADER ANIMATION 
function headerScroll() {
    var changeNavigationOn = 80;
    var sy = scrollY();
    // console.log($(window).innerWidth());
    if ($(window).innerWidth() > 991) {
        if (sy >= changeNavigationOn) {
            // console.log("ON");
            $("header").removeClass('changeHeaderOn');
        } else {
            $("header").removeClass('changeHeaderOn');
        }
        if (sy >= 10) {
            $("header").addClass('changeHeaderOn');
        }
    }
}

function scrollY() {
	return window.pageYOffset || document.documentElement.scrollTop;
}

/*------------------------------------------------*/
/*Equal Height Function
/*------------------------------------------------*/

function fnEqualHeight(container){
	var currentTallest = 0,
	     currentRowStart = 0,
	     rowDivs = new Array(),
	     $el,
	     topPosition = 0;
	     
 	$(container).each(function() {
	   $el = $(this);
	   $($el).height('auto');
	   topPostion = $el.position().top;

	   if (currentRowStart != topPostion) {
	     for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
	       rowDivs[currentDiv].height(currentTallest);
	     }
	     rowDivs.length = 0; // empty the array
	     currentRowStart = topPostion;
	     currentTallest = $el.height();
	     rowDivs.push($el);
	   } else {
	     rowDivs.push($el);
	     currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
	  }
	   for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
	     rowDivs[currentDiv].height(currentTallest+20);
	   }
 	});
}